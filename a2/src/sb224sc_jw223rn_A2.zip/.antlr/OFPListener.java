// Generated from /home/fred/Documents/4dt902/a2/src/OFP.g4 by ANTLR 4.13.1

    package generated;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link OFPParser}.
 */
public interface OFPListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link OFPParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(OFPParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(OFPParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#main}.
	 * @param ctx the parse tree
	 */
	void enterMain(OFPParser.MainContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#main}.
	 * @param ctx the parse tree
	 */
	void exitMain(OFPParser.MainContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#funcDecl}.
	 * @param ctx the parse tree
	 */
	void enterFuncDecl(OFPParser.FuncDeclContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#funcDecl}.
	 * @param ctx the parse tree
	 */
	void exitFuncDecl(OFPParser.FuncDeclContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#funcCall}.
	 * @param ctx the parse tree
	 */
	void enterFuncCall(OFPParser.FuncCallContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#funcCall}.
	 * @param ctx the parse tree
	 */
	void exitFuncCall(OFPParser.FuncCallContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#block}.
	 * @param ctx the parse tree
	 */
	void enterBlock(OFPParser.BlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#block}.
	 * @param ctx the parse tree
	 */
	void exitBlock(OFPParser.BlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#funcBlock}.
	 * @param ctx the parse tree
	 */
	void enterFuncBlock(OFPParser.FuncBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#funcBlock}.
	 * @param ctx the parse tree
	 */
	void exitFuncBlock(OFPParser.FuncBlockContext ctx);
	/**
	 * Enter a parse tree produced by the {@code PrintStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterPrintStmt(OFPParser.PrintStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code PrintStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitPrintStmt(OFPParser.PrintStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code FuncCallStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterFuncCallStmt(OFPParser.FuncCallStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FuncCallStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitFuncCallStmt(OFPParser.FuncCallStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AssignStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterAssignStmt(OFPParser.AssignStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AssignStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitAssignStmt(OFPParser.AssignStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code VarDeclStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterVarDeclStmt(OFPParser.VarDeclStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code VarDeclStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitVarDeclStmt(OFPParser.VarDeclStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IfStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterIfStmt(OFPParser.IfStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IfStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitIfStmt(OFPParser.IfStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code WhileStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterWhileStmt(OFPParser.WhileStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code WhileStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitWhileStmt(OFPParser.WhileStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ReturnStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterReturnStmt(OFPParser.ReturnStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ReturnStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitReturnStmt(OFPParser.ReturnStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BoolExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBoolExpr(OFPParser.BoolExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BoolExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBoolExpr(OFPParser.BoolExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code StringExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterStringExpr(OFPParser.StringExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code StringExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitStringExpr(OFPParser.StringExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IDExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIDExpr(OFPParser.IDExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IDExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIDExpr(OFPParser.IDExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code FloatExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFloatExpr(OFPParser.FloatExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FloatExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFloatExpr(OFPParser.FloatExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code RelExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterRelExpr(OFPParser.RelExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code RelExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitRelExpr(OFPParser.RelExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ArrayInitExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterArrayInitExpr(OFPParser.ArrayInitExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ArrayInitExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitArrayInitExpr(OFPParser.ArrayInitExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ArrayAccessExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterArrayAccessExpr(OFPParser.ArrayAccessExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ArrayAccessExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitArrayAccessExpr(OFPParser.ArrayAccessExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code MultExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterMultExpr(OFPParser.MultExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code MultExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitMultExpr(OFPParser.MultExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ArrayLengthExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterArrayLengthExpr(OFPParser.ArrayLengthExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ArrayLengthExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitArrayLengthExpr(OFPParser.ArrayLengthExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code UnaryExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterUnaryExpr(OFPParser.UnaryExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code UnaryExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitUnaryExpr(OFPParser.UnaryExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CharExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterCharExpr(OFPParser.CharExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CharExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitCharExpr(OFPParser.CharExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code AddiExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterAddiExpr(OFPParser.AddiExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code AddiExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitAddiExpr(OFPParser.AddiExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code EqExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterEqExpr(OFPParser.EqExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code EqExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitEqExpr(OFPParser.EqExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IntExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIntExpr(OFPParser.IntExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IntExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIntExpr(OFPParser.IntExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ParenExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterParenExpr(OFPParser.ParenExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ParenExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitParenExpr(OFPParser.ParenExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code FuncCallExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFuncCallExpr(OFPParser.FuncCallExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FuncCallExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFuncCallExpr(OFPParser.FuncCallExprContext ctx);
}