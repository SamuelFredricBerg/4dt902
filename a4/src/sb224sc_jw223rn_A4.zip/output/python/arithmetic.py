p = None
q = None
r = None
p = 2
q = p + 2
r = p + q*3
print(r)
a = 2.0 - (1.0 + 0.2345)
b = a + 2.0
c = a + b*3.0
print(c)
